# Copyright © NavInfo Europe 2023.
# Adapted from SimMIM and BEIT.

import numpy as np
import cv2
import copy
import math
import random
import torch
import pywt

import os
from PIL import Image
from IPython.display import Image as Img
from IPython.display import display

import matplotlib.pyplot as plt

from imagecorruptions import corrupt, get_corruption_names

import pickle

import torchvision
from einops import rearrange
#from mtsfmlearner.global_vars import CURRENT_EPOCH

image_size = (640,192)

class F_MaskGenerator:
    def __init__(self, img, img_shape=(192, 640), mask_patch_size=32, model_patch_size=32, mask_ratio=0.25,
                 mask_strategy='random', temperature=1, frequency = 'high', idx = 0):
        self.img = img
        self.img_shape = img_shape
        self.mask_patch_size = mask_patch_size
        self.model_patch_size = model_patch_size
        self.mask_ratio = mask_ratio
        self.mask_strategy = mask_strategy
        self.temperature = temperature
        self.frequency = frequency
        self.idx = int(idx)
        
        self.show_max = 0.1
        self.show_ratio = self.show_max * self.mask_ratio

        assert self.img_shape[0] % self.mask_patch_size == 0
        assert self.img_shape[1] % self.mask_patch_size == 0
        assert self.mask_patch_size % self.model_patch_size == 0

        self.token_shape = np.zeros(len(self.img_shape), dtype=int)
        self.token_shape[0] = self.img_shape[0] // self.mask_patch_size
        self.token_shape[1] = self.img_shape[1] // self.mask_patch_size
        self.scale = self.mask_patch_size // self.model_patch_size

        self.token_count = self.token_shape[0] * self.token_shape[1]
        self.mask_count = int(np.ceil(self.token_count * self.mask_ratio))
        
        # High-pass filter 생성
        '''
        center = self.mask_patch_size // 2
        self.high_pass_filter = torch.zeros((self.mask_patch_size, self.mask_patch_size), device=img.device)
        self.low_pass_filter = torch.ones((self.mask_patch_size, self.mask_patch_size), device=img.device)
        for i in range(self.mask_patch_size):
            for j in range(self.mask_patch_size):
                distance = np.sqrt((i - center) ** 2 + (j - center) ** 2)
                if distance > self.filter_size:  # 원의 반지름을 조절하여 고주파 정보를 제어할 수 있습니다.
                    self.high_pass_filter[i, j] = 1
                    self.low_pass_filter[i, j] = 0
        '''
                    
    def random_masking(self):
        mask = np.zeros(shape=self.token_count, dtype=int)
        mask_idx = np.random.permutation(self.token_count)[:self.mask_count]
        mask[mask_idx] = 1

        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        return mask

    def blockwise_masking(self, min_num_mask_patches=16,
                          min_blockwise_aspect=0.3):
        mask = np.zeros(shape=self.token_count, dtype=int)
        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        num_tokens_masked = 0
        NUM_TRIES = 10
        max_blockwise_aspect = 1 / min_blockwise_aspect
        log_aspect_ratio = (math.log(min_blockwise_aspect), math.log(max_blockwise_aspect))
        while num_tokens_masked < self.mask_count:
            max_mask_patches = self.mask_count - num_tokens_masked

            delta = 0
            for attempt in range(NUM_TRIES):
                target_area = random.uniform(min_num_mask_patches, max_mask_patches)
                aspect_ratio = math.exp(random.uniform(*log_aspect_ratio))
                h = int(round(math.sqrt(target_area * aspect_ratio)))
                w = int(round(math.sqrt(target_area / aspect_ratio)))
                if h < self.token_shape[0] and w < self.token_shape[1]:
                    top = random.randint(0, self.token_shape[0] - h)
                    left = random.randint(0, self.token_shape[1] - w)

                    num_masked = mask[top: top + h, left: left + w].sum()
                    # Overlap
                    if 0 < h * w - num_masked <= max_mask_patches:
                        for i in range(top, top + h):
                            for j in range(left, left + w):
                                if mask[i, j] == 0:
                                    mask[i, j] = 1
                                    delta += 1

                    if delta > 0:
                        break

            if delta == 0:
                break
            else:
                num_tokens_masked += delta

        return mask
                
    def __call__(self):
        if self.mask_strategy == 'random':
            mask = self.random_masking()
        elif self.mask_strategy == 'blockwise':
            mask = self.blockwise_masking()
        elif self.mask_strategy == 'frask_random':
            mask = self.frask_random(self.img, self.mask_patch_size, self.frequency, self.temperature)
        elif self.mask_strategy == 'frask':
            mask = self.frask(self.img, self.mask_patch_size, self.frequency, self.temperature)
        elif self.mask_strategy == 'attention':
            mask = self.att_masking(self.img, self.mask_patch_size, self.frequency)
        elif self.mask_strategy == 'fre_masking':
            mask = self.fre_masking(self.img, self.mask_patch_size, self.frequency)
        elif self.mask_strategy == 'att_ours':
            mask = self.att_ours(self.img, self.mask_patch_size, self.frequency)
        elif self.mask_strategy == 'att_sort':
            mask = self.att_sort(self.img, self.mask_patch_size, self.frequency)
        elif self.mask_strategy == 'wavelet':
            mask = self.wavelet(self.img, self.mask_patch_size, frequency=self.frequency)
        elif self.mask_strategy == 'wavelet_random':
            mask = self.wavelet_random(self.img, self.mask_patch_size, frequency=self.frequency)
        else:
            raise NotImplementedError
        #mask = mask.repeat(self.scale, axis=0).repeat(self.scale, axis=1)
        return mask

    def wavelet_random(self, img, mask_patch_size, frequency='+'):
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        patch_magnitudes = []
        
        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        LL, yh = pywt.dwt2(gray_image.cpu(), 'haar')

        yh = torch.Tensor(np.array(yh))
        yh = torch.max(abs(yh),dim=0)[0]

        patch_magnitudes = []
        height, width = yh.shape
        patch_size = mask_patch_size // 2
        for y in range(0, height, patch_size):
            for x in range(0, width, patch_size):
                patch = yh[y:y+patch_size, x:x+patch_size]
                patch_magnitudes.append(patch.sum())
        magnitudes = torch.Tensor(patch_magnitudes)

        if '-' in frequency:
            magnitudes = -torch.Tensor(magnitudes)
            
        softmax_values = softmax((magnitudes - magnitudes.min()) / (magnitudes.max() - magnitudes.min()), 1) # normalize

        mask_idx = torch_choice(self.token_count, self.mask_count, replace=False, p=softmax_values)

        mask = np.zeros(shape=self.token_count, dtype=int)
        mask[mask_idx] = 1

        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        return mask
    
    def wavelet(self, img, mask_patch_size, min_num_mask_patches=16, min_blockwise_aspect=0.3, frequency='+'):
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        patch_magnitudes = []
        
        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        LL, yh = pywt.dwt2(gray_image.cpu(), 'haar')

        yh = torch.Tensor(np.array(yh))
        yh = torch.max(abs(yh),dim=0)[0]

        patch_magnitudes = []
        height, width = yh.shape
        patch_size = mask_patch_size // 2
        for y in range(0, height, patch_size):
            for x in range(0, width, patch_size):
                patch = yh[y:y+patch_size, x:x+patch_size]
                patch_magnitudes.append(patch.sum())
        magnitudes = torch.Tensor(patch_magnitudes)
        
        if '-' in frequency:
            magnitudes = -torch.Tensor(magnitudes)
            
        softmax_values = softmax((magnitudes - magnitudes.min()) / (magnitudes.max() - magnitudes.min()), 1) # normalize

        mask = np.zeros(shape=self.token_count, dtype=int)
        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        num_tokens_masked = 0
        NUM_TRIES = 10
        max_blockwise_aspect = 1 / min_blockwise_aspect
        log_aspect_ratio = (math.log(min_blockwise_aspect), math.log(max_blockwise_aspect))
        while num_tokens_masked < self.mask_count:
            max_mask_patches = self.mask_count - num_tokens_masked

            delta = 0
            for attempt in range(NUM_TRIES):
                target_area = random.uniform(min_num_mask_patches, max_mask_patches)
                aspect_ratio = math.exp(random.uniform(*log_aspect_ratio))
                h = int(round(math.sqrt(target_area * aspect_ratio)))
                w = int(round(math.sqrt(target_area / aspect_ratio)))
                if h < self.token_shape[0] and w < self.token_shape[1]:
                    mask_idx = torch_choice(self.token_count, 1, p=softmax_values)[0]
                    top = mask_idx // self.token_shape[1] - h // 2
                    left = mask_idx % self.token_shape[1] - w // 2
                    num_masked = mask[max(0, top): min(top + h, self.token_shape[0]), max(0, left): min(left + w, self.token_shape[1])].sum()
                    # Overlap
                    if 0 < h * w - num_masked <= max_mask_patches:
                        for i in range(max(0, top), min(top + h, self.token_shape[0])):
                            for j in range(max(0, left), min(left + w, self.token_shape[1])):
                                if mask[i, j] == 0:
                                    mask[i, j] = 1
                                    delta += 1

                    if delta > 0:
                        break

            if delta == 0:
                break
            else:
                num_tokens_masked += delta
        return mask

    
    def frask_random(self, img, mask_patch_size, frequency='low', temperature=1):
        # 이미지 크기 및 패치 크기 가져오기
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        patch_magnitudes = []
        
        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        patch_magnitudes = rearrange(gray_image, '(h p1) (w p2) -> (h w) p1 p2',  p1 = mask_patch_size, p2 = mask_patch_size)
        patch_magnitudes = torch.abs(torch.fft.fft2(patch_magnitudes))
        magnitudes = torch.sum(patch_magnitudes, (-1,-2))
        '''
        for y in range(0, height, mask_patch_size):
            for x in range(0, width, mask_patch_size):
                patch = gray_image[y:y+mask_patch_size, x:x+mask_patch_size]
                patch_fft = torch.fft.fft2(patch)
                #patch_fft = torch.fft.fftshift(patch_fft)
                #magnitude = torch.log1p(torch.abs(patch_fft))
                magnitude = torch.abs(patch_fft)
                patch_magnitudes.append(magnitude)

        if 'low' in frequency:
            magnitudes = [torch.sum(magnitude * self.low_pass_filter) for magnitude in patch_magnitudes]
        elif 'all' in frequency:
            magnitudes = [torch.sum(magnitude) for magnitude in patch_magnitudes]
        else:
            magnitudes = [torch.sum(magnitude * self.high_pass_filter) for magnitude in patch_magnitudes]
        '''
        if '-' in frequency:
            magnitudes = -magnitudes # torch.Tensor(magnitudes)
        # else:
        #    magnitudes = torch.Tensor(magnitudes)
        
        softmax_values = softmax((magnitudes - magnitudes.min()) / (magnitudes.max() - magnitudes.min()), temperature) # normalize

        mask_idx = torch_choice(self.token_count, self.mask_count, replace=False, p=softmax_values)

        mask = np.zeros(shape=self.token_count, dtype=int)
        mask[mask_idx] = 1

        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        return mask
    
    def frask(self, img, mask_patch_size, frequency='low', temperature=1, min_num_mask_patches=16,
                          min_blockwise_aspect=0.3):
        
        # 이미지 크기 및 패치 크기 가져오기
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        patch_magnitudes = []
        
        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        #epoch_ratio = (CURRENT_EPOCH*40/19+10)*0.01#(50-CURRENT_EPOCH*40/19)*0.01
        #self.mask_count = int(np.ceil(self.token_count * epoch_ratio))
        patch_magnitudes = rearrange(gray_image, '(h p1) (w p2) -> (h w) p1 p2',  p1 = mask_patch_size, p2 = mask_patch_size) # 6*20 32 32
        patch_magnitudes = torch.abs(torch.fft.fft2(patch_magnitudes)) # 6*20 32 32
        magnitudes = torch.sum(patch_magnitudes, (-1,-2)) # 6*20
        '''
        for y in range(0, height, mask_patch_size):
            for x in range(0, width, mask_patch_size):
                patch = gray_image[y:y+mask_patch_size, x:x+mask_patch_size]
                patch_fft = torch.fft.fft2(patch)
                #patch_fft = torch.fft.fftshift(patch_fft)
                #magnitude = torch.log1p(torch.abs(patch_fft))
                magnitude = torch.abs(patch_fft)
                patch_magnitudes.append(magnitude)

        if 'low' in frequency:
            magnitudes = [torch.sum(magnitude * self.low_pass_filter) for magnitude in patch_magnitudes]
        elif 'all' in frequency:
            magnitudes = [torch.sum(magnitude) for magnitude in patch_magnitudes]
        else:
            magnitudes = [torch.sum(magnitude * self.high_pass_filter) for magnitude in patch_magnitudes]
        '''
        if '-' in frequency:
            magnitudes = -magnitudes # torch.Tensor(magnitudes)
        # else:
        #    magnitudes = torch.Tensor(magnitudes)
        
        softmax_values = softmax((magnitudes - magnitudes.min()) / (magnitudes.max() - magnitudes.min()), temperature) # normalize

        mask = np.zeros(shape=self.token_count, dtype=int)
        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        num_tokens_masked = 0
        NUM_TRIES = 10
        max_blockwise_aspect = 1 / min_blockwise_aspect
        log_aspect_ratio = (math.log(min_blockwise_aspect), math.log(max_blockwise_aspect))
        while num_tokens_masked < self.mask_count:
            max_mask_patches = self.mask_count - num_tokens_masked

            delta = 0
            for attempt in range(NUM_TRIES):
                target_area = random.uniform(min_num_mask_patches, max_mask_patches)
                aspect_ratio = math.exp(random.uniform(*log_aspect_ratio))
                h = int(round(math.sqrt(target_area * aspect_ratio)))
                w = int(round(math.sqrt(target_area / aspect_ratio)))
                if h < self.token_shape[0] and w < self.token_shape[1]:
                    mask_idx = torch_choice(self.token_count, 1, p=softmax_values)[0]
                    top = mask_idx // self.token_shape[1] - h // 2
                    left = mask_idx % self.token_shape[1] - w // 2
                    num_masked = mask[max(0, top): min(top + h, self.token_shape[0]), max(0, left): min(left + w, self.token_shape[1])].sum()
                    # Overlap
                    if 0 < h * w - num_masked <= max_mask_patches:
                        for i in range(max(0, top), min(top + h, self.token_shape[0])):
                            for j in range(max(0, left), min(left + w, self.token_shape[1])):
                                if mask[i, j] == 0:
                                    mask[i, j] = 1
                                    delta += 1

                    if delta > 0:
                        break

            if delta == 0:
                break
            else:
                num_tokens_masked += delta
        
        if 'hint' in frequency:
            mask = mask.reshape(-1)
            mask = show_hints(mask, mask, self.show_ratio)
            mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        return mask

    def att_masking(self, img, mask_patch_size, att='low'):
        # 이미지 크기 및 패치 크기 가져오기
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size
        
        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


        #with open('/data/sundong/repos/MIMDepth/data/kitti_data.pkl', 'rb') as f:
        with open('/data/sundong/repos/MIMDepth/data/dinov2-base.pkl', 'rb') as f:
            kitti_data = pickle.load(f)
        #print(self.idx)
        patch_magnitudes = kitti_data[self.idx]

        if att == 'low':
            mask_idx = np.argsort(patch_magnitudes)[:self.mask_count]
        else:
            mask_idx = np.argsort(patch_magnitudes)[::-1][:self.mask_count]
        #mask_idx = torch_choice(self.token_count, self.mask_count, replace=False, p=prob)
        mask = np.zeros(shape=self.token_count, dtype=int)
        mask[mask_idx] = 1
        generator = torch.rand(mask.shape[0])
        mask[generator > 0.5] = 0

        top_mask = np.zeros(shape=self.token_count, dtype=int)
        top_mask_idx = np.argsort(patch_magnitudes)[::-1][:int(np.ceil(self.token_count * self.show_max))]
        top_mask[top_mask_idx] = 1

        if att == 'hint':
            mask = show_hints(top_mask, mask, self.show_ratio)

        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        return mask
        
    def att_ours(self, img, mask_patch_size, frequency='low', min_num_mask_patches=16,
                          min_blockwise_aspect=0.3):
        # 이미지 크기 및 패치 크기 가져오기
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


        with open('/data/sundong/repos/MIMDepth/data/dinov2-base.pkl', 'rb') as f:
        #with open('/data/sundong/repos/MIMDepth/data/kitti_data.pkl', 'rb') as f:
            kitti_data = pickle.load(f)
        #print(self.idx)
        patch_magnitudes = kitti_data[self.idx]
        if frequency == 'low':
            magnitudes = - torch.Tensor(patch_magnitudes)
        else:
            magnitudes = torch.Tensor(patch_magnitudes)
        softmax_values = softmax((magnitudes - magnitudes.min()) / (magnitudes.max() - magnitudes.min()), 1) # normalize

        mask = np.zeros(shape=self.token_count, dtype=int)
        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        num_tokens_masked = 0
        NUM_TRIES = 10
        max_blockwise_aspect = 1 / min_blockwise_aspect
        log_aspect_ratio = (math.log(min_blockwise_aspect), math.log(max_blockwise_aspect))
        while num_tokens_masked < self.mask_count:
            max_mask_patches = self.mask_count - num_tokens_masked

            delta = 0
            for attempt in range(NUM_TRIES):
                target_area = random.uniform(min_num_mask_patches, max_mask_patches)
                aspect_ratio = math.exp(random.uniform(*log_aspect_ratio))
                h = int(round(math.sqrt(target_area * aspect_ratio)))
                w = int(round(math.sqrt(target_area / aspect_ratio)))
                if h < self.token_shape[0] and w < self.token_shape[1]:
                    mask_idx = torch_choice(self.token_count, 1, p=softmax_values)[0]
                    top = mask_idx // self.token_shape[1] - h // 2
                    left = mask_idx % self.token_shape[1] - w // 2
                    num_masked = mask[max(0, top): min(top + h, self.token_shape[0]), max(0, left): min(left + w, self.token_shape[1])].sum()
                    # Overlap
                    if 0 < h * w - num_masked <= max_mask_patches:
                        for i in range(max(0, top), min(top + h, self.token_shape[0])):
                            for j in range(max(0, left), min(left + w, self.token_shape[1])):
                                if mask[i, j] == 0:
                                    mask[i, j] = 1
                                    delta += 1

                    if delta > 0:
                        break

            if delta == 0:
                break
            else:
                num_tokens_masked += delta

        return mask

    def att_sort(self, img, mask_patch_size, frequency='low', min_num_mask_patches=16,
                          min_blockwise_aspect=0.3):
        # 이미지 크기 및 패치 크기 가져오기
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


        with open('/data/sundong/repos/MIMDepth/data/dinov2-base.pkl', 'rb') as f:
        #with open('/data/sundong/repos/MIMDepth/data/kitti_data.pkl', 'rb') as f:
            kitti_data = pickle.load(f)
        #print(self.idx)
        patch_magnitudes = kitti_data[self.idx]

        if frequency == 'low':
            mask_idxs = np.argsort(patch_magnitudes)[:self.mask_count]
        else:
            mask_idxs = np.argsort(patch_magnitudes)[::-1][:self.mask_count]
            
        mask = np.zeros(shape=self.token_count, dtype=int)
        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        num_tokens_masked = 0
        NUM_TRIES = 10
        max_blockwise_aspect = 1 / min_blockwise_aspect
        log_aspect_ratio = (math.log(min_blockwise_aspect), math.log(max_blockwise_aspect))
        while num_tokens_masked < self.mask_count:
            max_mask_patches = self.mask_count - num_tokens_masked

            delta = 0
            for attempt in range(NUM_TRIES):
                target_area = random.uniform(min_num_mask_patches, max_mask_patches)
                aspect_ratio = math.exp(random.uniform(*log_aspect_ratio))
                h = int(round(math.sqrt(target_area * aspect_ratio)))
                w = int(round(math.sqrt(target_area / aspect_ratio)))
                if h < self.token_shape[0] and w < self.token_shape[1]:
                    mask_idx = torch_choice(mask_idxs, 1)[0]
                    top = mask_idx // self.token_shape[1] - h // 2
                    left = mask_idx % self.token_shape[1] - w // 2
                    num_masked = mask[max(0, top): min(top + h, self.token_shape[0]), max(0, left): min(left + w, self.token_shape[1])].sum()
                    # Overlap
                    if 0 < h * w - num_masked <= max_mask_patches:
                        for i in range(max(0, top), min(top + h, self.token_shape[0])):
                            for j in range(max(0, left), min(left + w, self.token_shape[1])):
                                if mask[i, j] == 0:
                                    mask[i, j] = 1
                                    delta += 1

                    if delta > 0:
                        break

            if delta == 0:
                break
            else:
                num_tokens_masked += delta

        return mask

    def fre_masking(self, img, mask_patch_size, frequency='low'):
        # 이미지 크기 및 패치 크기 가져오기
        channels, height, width = img.shape
        h_patches = height // mask_patch_size
        w_patches = width // mask_patch_size

        patch_magnitudes = []
        
        gray_image = torchvision.transforms.functional.rgb_to_grayscale(img, num_output_channels=1).squeeze() # cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        for y in range(0, height, mask_patch_size):
            for x in range(0, width, mask_patch_size):
                patch = gray_image[y:y+mask_patch_size, x:x+mask_patch_size]
                patch_fft = torch.fft.fft2(torch.from_numpy(patch))
                patch_fft = torch.fft.fftshift(patch_fft)
                magnitude = torch.log1p(torch.abs(patch_fft))
                patch_magnitudes.append(magnitude)

        magnitudes = [torch.sum(magnitude* self.high_pass_filter) for magnitude in patch_magnitudes]

        patch_magnitudes = torch.Tensor(magnitudes)

        if frequency == 'low':
            mask_idx = np.argsort(patch_magnitudes)[:self.mask_count]
        else:
            mask_idx = np.argsort(patch_magnitudes)[::-1][:self.mask_count]
        #mask_idx = torch_choice(self.token_count, self.mask_count, replace=False, p=prob)
        mask = np.zeros(shape=self.token_count, dtype=int)
        mask[mask_idx] = 1
        generator = torch.rand(mask.shape[0])
        mask[generator > 0.5] = 0

        top_mask = np.zeros(shape=self.token_count, dtype=int)
        top_mask_idx = np.argsort(patch_magnitudes)[::-1][:int(np.ceil(self.token_count * self.show_max))]
        top_mask[top_mask_idx] = 1

        if frequency == 'hint':
            mask = show_hints(top_mask, mask, self.show_ratio)

        mask = mask.reshape((self.token_shape[0], self.token_shape[1]))
        return mask
        
def show_hints(top_masks, masks, show_ratio):

    n_tokens = masks.shape[0]
    reveal_tokens = int(show_ratio*n_tokens)

    selected_high = torch.multinomial(torch.tensor(top_masks, dtype=torch.float), reveal_tokens)
    top_masks[selected_high] = 0

    return top_masks

class F_MIMTransform:
    def __init__(self, img, img_size, mask_patch_size, mask_ratio, mask_strategy='random', temperature=1, frequency='low', idx=0):
        model_patch_size = 16
        #img = cv2.cvtColor(np.transpose(img.numpy(), (1,2,0)), cv2.COLOR_RGB2BGR)
        self.mask_generator = F_MaskGenerator(
            img = img,
            img_shape=img_size,
            mask_patch_size=mask_patch_size,
            model_patch_size=model_patch_size,
            mask_ratio=mask_ratio,
            mask_strategy=mask_strategy,
            temperature = temperature,
            frequency = frequency,
            idx = idx
        )

    def __call__(self):
        mask = self.mask_generator()
        return mask

def softmax(x, t):
    x = x / t
    exp_x = torch.exp(x-x.max()) 
    return exp_x / exp_x.sum()
    
def torch_choice(a, size=None, replace=True, p=None):
    if isinstance(a, int):
        a = torch.arange(a)

    indices = torch.multinomial(p, size, replacement=replace)


    return indices
