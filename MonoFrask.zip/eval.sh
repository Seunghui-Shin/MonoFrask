#!/usr/bin/bash

#SBATCH --job-name=eval_MonoViT
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-gpu=8
#SBATCH --mem-per-gpu=29G
#SBATCH -p batch_grad
#SBATCH -w ariel-k1
#SBATCH -t 4-0
#SBATCH -o logs/eval_MonoViT-%A.out

source /data/sundong/init.sh
conda activate mono

#model=wavelet_random
#wandb login 50f78e741c97d29e32fce750604b12928b81b188
#python evaluate_depth.py --load_weights_folder ./tmp/pre/ --eval_mono
# random, blockwise, monovit, wavelet, wavelet_random, frask_low+_f11, frask_random_low+_f11
#models=('frask_all_t2.5' 'frask_all_t2')
#('frask_random_all_t0.1' 'frask_all_t0.1')
models=('frask_t0.5' 'frask_t1' 'frask_t1.5' 'frask_t2')
for model in ${models[@]};
do
  for epoch in {14..14}
  do
    python evaluate_depth.py --load_weights_folder ./tmp/${model}/models/weights_${epoch}/ --eval_mono
  done
done
#model=frask_low+_f11
#python evaluate_depth.py --load_weights_folder ./tmp/$model/models/weights_0/ --eval_mono

exit 0