#!/usr/bin/bash

#SBATCH --job-name=MonoViT
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-gpu=8
#SBATCH --mem-per-gpu=29G
#SBATCH -p batch_grad
#SBATCH -w ariel-g1
#SBATCH -t 4-0
#SBATCH -o logs/frask_t1_MonoViT-%A.out

source /data/sundong/init.sh
conda activate mono

#wandb login 50f78e741c97d29e32fce750604b12928b81b188

python train.py --model_name frask_t1 --learning_rate 5e-5 --png
exit 0